const express = require("express");
const app = express();
const port=6005;
app.set('view engine', 'ejs');
app.use(express.static('public'));

app.listen(port, (error)=>{
if(error){console.log("Server Failed")}
else{ console.log(`Server Started on port ${port}`)}
})
app.use(express.json());

function workingHours(req, res, next) {
    const date = new Date();
    const day = date.getDay();
    const hour = date.getHours();
  
    if (day >= 1 && day <= 7 && hour >= 9 && hour < 22) {
      next();
    } else {
      res.send("The website is only available during working hours (Monday to Friday, from 9 to 17).");
    }
  }
  
  app.use(workingHours);
//   app.get('/', (req, res) => {
//     res.send('<h1>Home Page</h1><nav><a href="/">Home</a> | <a href="/services">Our Services</a> | <a href="/contact">Contact Us</a></nav>');
//   });
  
//   app.get('/services', (req, res) => {
//     res.send('<h1>Our Services</h1><nav><a href="/">Home</a> | <a href="/services">Our Services</a> | <a href="/contact">Contact Us</a></nav>');
//   });
  
//   app.get('/contact', (req, res) => {
//     res.send('<h1>Contact Us</h1><nav><a href="/">Home</a> | <a href="/services">Our Services</a> | <a href="/contact">Contact Us</a></nav>');
//   });
     
app.get('/', (req, res) => res.render('home'));
app.get('/services', (req, res) => res.render('services'));
app.get('/contact', (req, res) => res.render('contact'));
